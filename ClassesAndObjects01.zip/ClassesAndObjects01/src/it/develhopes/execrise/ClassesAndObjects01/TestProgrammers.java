package it.develhopes.execrise.ClassesAndObjects01;

public class TestProgrammers {
    public static void main(String args[]){

        Programmer drinkCoffe = new Programmer();
        drinkCoffe.name = "Espresso is the secret!";
        drinkCoffe.age = 19;
        drinkCoffe.wearsGlasses = false;
        System.out.println("drinkCofee " + drinkCoffe.name  + " - " + drinkCoffe.age + " - " + drinkCoffe.wearsGlasses);

        Programmer printDetails = new Programmer();
        printDetails.name = "NameHere is a AgeHere-yo programmer";
        printDetails.age = 20;
        printDetails.wearsGlasses = false;
        System.out.println("drinkCofee " + printDetails.name  + " - " + printDetails.age + " - " + printDetails.wearsGlasses);

        Programmer hasGlasses = new Programmer();
        hasGlasses.name = "Is NameHere wearing glasses? ";
        hasGlasses.age = 25;
        hasGlasses.wearsGlasses = true;
        System.out.println("hasGlasses " + hasGlasses.name + " - " + hasGlasses.age + " - " + hasGlasses.wearsGlasses);
    }
}
