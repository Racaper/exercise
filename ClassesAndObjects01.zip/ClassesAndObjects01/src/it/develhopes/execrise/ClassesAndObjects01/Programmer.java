package it.develhopes.execrise.ClassesAndObjects01;

public class Programmer {

        String name;
        int age;
        boolean wearsGlasses;

        public String print(){
            return name + " - " + age + " - " + wearsGlasses;
        }

    public static void main(String args[]){

        Programmer drinkCoffe = new Programmer();
        drinkCoffe.name = "Espresso is the secret!";
        System.out.println("drinkCofee " + drinkCoffe.name);

        Programmer printDetails = new Programmer();
        printDetails.name = "NameHere is a AgeHere-yo programmer";
        System.out.println("printDetails " + printDetails.name);

        Programmer hasGlasses = new Programmer();
        hasGlasses.name = "Is NameHere wearing glasses? ";
        hasGlasses.wearsGlasses = true;
        System.out.println("hasGlasses " + hasGlasses.name + " - " + hasGlasses.wearsGlasses);
    }
}

