package it.develhopes.Exercise.ClassesAndObjects02;

public class Team {
    String teamName;

    public String print(){
        return teamName;
    }

}
