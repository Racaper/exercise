package it.develhopes.Exercise.ClassesAndObjects02;

public class Programmer {
    String name;
    String programmingLanguage;
    int yearsOfExperience;

    public String print(){
        return name + " - " + programmingLanguage + " - " + yearsOfExperience;
    }
}
